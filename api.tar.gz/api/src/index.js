const {response, request} = require('express');
const express = require('express');

const app = express();

app.get("/texto",(request,response) =>
 {
    return response.send("Bom inicio");  


});

app.get("/json",(request,response) =>{

    return response.json({"message": "Bom inicio"});

});

app.get("/texto2",(request,response)=>{

return response.send("Bom inicio 2");    
});


app.get("/products", (request,response) =>{
    return response.json(
        [{
            "id": "1",
            "nome": "Caderno Pequeno",
            "image": "caderno.png",
            "categoria": "7",
            "descricao": "caderno universitario 20 folhas",
            "status": "ativo"

    

        },

{       "id": "2",
        "nome": "Caderno Pequeno",
        "image": "caderno.png",
        "categoria": "7",
        "descricao": "caderno universitario 20 folhas",
        "status": "ativo"


        }
    
    ]

    );
});
/* método post para inserir uma informação */


app.post("/incluir", (request,response) =>{
const body = request.body;
console.log(body)
const{nome,image,categoria,descricao,status} = request.body;
min = Math.ceil(0);
max = Math.floor(99);
const id= Math.floor(Math.random() * (max - min)) + min

 var objeto = {
    id,
    nome,
    image,
    categoria,
    status,
    descricao
 }

 return response.json(objeto);
});



app.listen(3000);