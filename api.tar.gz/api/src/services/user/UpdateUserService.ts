interface IUserRequest {
    name: string;
    email: string;
    admin?: boolean;
    password: string;
  }
  
  class UpdateUserService {
    async execute({ name, email, admin = false, password }: IUserRequest) {
     
  
      if (!email) {
        throw new Error("Email incorrect");
      }
  
       var vuser = {
        name:"Nome 1", email:"email 2", admin:"teste", password:1234
      }
  
      return vuser;
    }
  }
  
  export { UpdateUserService };
  